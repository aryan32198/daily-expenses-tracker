<div class="col-sm-12">
				<p class="back-link">Daily Expense Tracker | DESIGN BY YASH VARDHAN SRIVASTAVA SEL</a></p>
			</div>
